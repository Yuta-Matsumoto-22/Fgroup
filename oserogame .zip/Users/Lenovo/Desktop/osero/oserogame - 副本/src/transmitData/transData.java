package transmitData;

import java.io.Serializable;

public class transData implements Serializable{
	private static final long serialVersionUID = 1L;
	int protocol=3;
	int row=-1;//��
	int line=-1;//��
	public transData(int row,int line) {
		this.row=row;
		this.line=line;
	}
	public int getRow() {
		return row;
	}
	public int getLine() {
		return line;
	}
	public int getProtocol() {
		return protocol;
	}
}//transDate
//object ���͵�ע��㣺