package sever;

import java.net.*;
import java.io.*;
import user.*;
import transmitData.*;
public class server {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int port = 10001;
	
	try {
		
		ServerSocket ss = new ServerSocket(port);
		User user;
		while (true) {
			
			Socket s = ss.accept();
			System.out.println("Server Starting");
			InputStream is = s.getInputStream();
			ObjectInputStream ois = new ObjectInputStream(is);
			transData data =(transData)ois.readObject();
			if(data instanceof transData) {
				
				System.out.println(data.getProtocol());
			}
			
				
			/*user = (User)ois.readObject();
			String password ="pswinit";
			String username ="userinit";
			password = user.getpassword();
			username = user.getusername();
			
			System.out.println("#Server Username: "+ username);
			System.out.println("#Server Password: "+ password);
			*/
		}
		
	}catch(Exception err) {
		err.printStackTrace();
		
	}	
	}
	
}